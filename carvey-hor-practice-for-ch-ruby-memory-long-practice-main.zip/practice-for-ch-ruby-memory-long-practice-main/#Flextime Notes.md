#Flextime Notes

n**m #This is exponential: n to the mth power

values = VALUES #this way we grab the vals of a class constant without performing operations on the class constant direct

the last line of methods that don't return should be nil, to ensure we don't return the eval
of the last line, making the method safer

Can also implement factory method to create the n cards needed